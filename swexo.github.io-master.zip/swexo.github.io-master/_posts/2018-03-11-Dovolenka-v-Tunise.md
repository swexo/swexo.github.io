---
layout: skuska
title: "Dovolenka v Tunise"
date: 2018-03-11
---

# Dovolenka v Tunise
---
	Cez leto minulého roku, som sa s priateľkou(teraz už bývalou) rozhodol, že pojdeme na dovolenku. 
	Po dlhom zvažovaní našich možností, prehľadávaní rôznych destinácií sme sa nakoniec rozhodli, že pojdeme do Tunisu. 
	Išli sme tam na 12 nocí. Hotel,ktorý sme si vybrali nebol nič extra, no nám sa tam páčilo. Samozrejme ubytovanie sme
	mali "all - inclusive" ako je na tieto typy dovoleniek bežné. Pláž bola síce malá ale piesok bol úplne super. 
	Slnko pieklo celý deň, takže sme domov priľli ako kominári.
	Počas dovolenky sme s bývalou išli na pirátsku ľoď a boli sme sa preletieť balónom, kroý ťahal vodný čln. 
	Celkovo dovolenku.
