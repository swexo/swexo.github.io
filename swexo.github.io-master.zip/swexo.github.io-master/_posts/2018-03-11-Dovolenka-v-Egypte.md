---
layout: skuska
title: "Dovolenka v Egypte"
date: 2018-03-11
---
# Dovolenka v Egypte
---
	Moji rodičia od malička somnou a s mojou sestrou Zuzanou cez leto cestovali na dovolenku. Precestovali sme polku Európy 
	a zabládili sme aj do Afriky.Preto v roku 2005 sme ako prvý krát navštívili Egypt. Boli sme v Hurghade v hotely Sea Gull.
	Bol to veľký luxusný hotel, s velikánskou recepciou, veľa bazénmi styrmi barmi a mnohými inými super vecami. 
	Pobyt nám trval 12 dní a 11 nocí. Strava bola výborná, množstvo jedál servírovaných ako švídske stoly. Pláž bola tiež
	super. Velikánska s krásnym morom. červené more je to najkrajšie more podľa môjho názoru. Celé dni som len šnorchľoval a 
	spoznával krásy podmorského života. Ten ma natoľko uchvátil, že sme sa nakoniec boli aj potápať. Celkovo to bola výborná 
	dovolenka, za ktorú mojim rodičom ďakujem.